 #pragma once
 #include <iostream>
 #include <sys/types.h>
 #include <unistd.h>
 #include <sys/wait.h>
 #include <fstream>
 #include <cstring>