int main()
{
int count =0;
	signal(SIGUSR1, Signal_handler);
	cout<<"\n Received SIGUSR1 is : "<<user<<endl;

	char str1[SIZE] = "Hello";																		   
	buf = strcat( str1, " Program" );
	cout<<"\n Concatenated string is : "<<str1<<endl;
																										   				
	signal(SIGILL, signal_handler);
	while (++count) 
	{
		cout << "\n Hello all! Welcome!" << endl;       
		if (count == 3)
    	raise(SIGILL);
    }	
																											
