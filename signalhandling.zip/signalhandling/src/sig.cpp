#include <sig.h>

static void signal_handler(int ID)
{
	cout<<"\nInterrupt signal is ID : "<<ID<<endl;
	if(ID == 4)
	{ 
		cout<<"\n Segment core dump\n"<<endl;
		exit(EXIT_SUCCESS);
	}
}

char user[SIZE] = "Welcome User!";
char *buf;

void Signal_handler (int sig_num)
{   
	cout<<buf<<&user<<endl;
	exit(EXIT_SUCCESS);
}
