#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;
void EXIT_SUCCESS;
void EXIT_FAILURE;
