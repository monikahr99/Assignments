#include <iostream>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;
int main(int argc, char** argv)
{
 int num,pid,exitstat,status;
 num=N;
 int sumodd=0,sumeven=0;
 int n,i;
 n = fork();
 if (n>0)
 {
 for (i=1;i<=N;i++){
  if (a[i] % 2 == 0) {
  sumeven = sumeven + a[i];}
  }
  cout<<"parent process\n";
  cout<<"sum of even number is"<<sumeven<<endl;
  cout<<"EXIT_SUCCESS:";
  }
  else{
  for (i=1;i<=N;i++){
  if (a[i] % 2 ! = 0){
  sumodd = sumodd + a[i];}
  }
  cout<<"child process \n";
  cout<<"\n sum of odd no.is "<<sumodd<<endl;
  cout<<"
  
  }
  return 0;
  }
 
 
 

   


